//
//  NanoStoreGlobalsTests.h
//  NanoStore
//
//  Created by Tito Ciuro on 4/18/12.
//  Copyright 2010 Webbo, L.L.C. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface NanoStoreGlobalsTests : SenTestCase
{
}

@end
