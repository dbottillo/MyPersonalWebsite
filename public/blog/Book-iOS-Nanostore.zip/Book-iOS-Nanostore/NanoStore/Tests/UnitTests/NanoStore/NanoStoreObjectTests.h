//
//  NanoStoreObjectTests.h
//  NanoStore
//
//  Created by Tito Ciuro on 10/14/10.
//  Copyright 2010 Webbo, L.L.C. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface NanoStoreObjectTests : SenTestCase
{
    NSDictionary *_defaultTestInfo;
}

@end
