//
//  NanoStoreBagTests.h
//  NanoStore
//
//  Created by Tito Ciuro on 10/15/10.
//  Copyright 2010 Webbo, L.L.C. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface NanoStoreBagTests : SenTestCase
{
    NSDictionary *_defaultTestInfo;
}

@end
