//
//  NanoStoreTests.h
//  NanoStore
//
//  Created by Tito Ciuro on 3/12/08.
//  Copyright 2010 Webbo, L.L.C. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface NanoStoreTests : SenTestCase
{
    NSDictionary *_defaultTestInfo;
}

@end
