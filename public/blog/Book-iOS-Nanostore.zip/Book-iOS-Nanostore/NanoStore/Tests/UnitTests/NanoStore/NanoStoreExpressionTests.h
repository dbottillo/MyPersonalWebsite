//
//  NanoStoreExpressionTests.h
//  NanoStore
//
//  Created by Tito Ciuro on 3/30/08.
//  Copyright 2010 Webbo, L.L.C. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface NanoStoreExpressionTests : SenTestCase
{
    NSDictionary *_defaultTestInfo;
}

@end
