//
//  main.m
//  iPhoneTest
//
//  Created by Tito Ciuro on 24/08/10.
//  Copyright 2010 Webbo, L.L.C. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
