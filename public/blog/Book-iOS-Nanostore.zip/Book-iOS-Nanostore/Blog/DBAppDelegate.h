//
//  DBAppDelegate.h
//  Blog
//
//  Created by Daniele Bottillo on 5/26/13.
//  Copyright (c) 2013 Daniele Bottillo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DBAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
