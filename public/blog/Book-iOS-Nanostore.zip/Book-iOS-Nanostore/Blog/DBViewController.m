//
//  DBViewController.m
//  Blog
//
//  Created by Daniele Bottillo on 5/26/13.
//  Copyright (c) 2013 Daniele Bottillo. All rights reserved.
//

#import "DBViewController.h"
#import "NanoStore.h"
#import "Book.h"

@interface DBViewController ()
@property (strong, nonatomic) NSMutableArray *books;
@end

@implementation DBViewController

@synthesize books;
@synthesize tableView;

- (void)viewDidLoad{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [self reloadData];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) reloadData{
    NSString *docs = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSError *outError;
    NSFNanoStore *nanoStore = [NSFNanoStore createAndOpenStoreWithType:NSFPersistentStoreType path:[docs stringByAppendingPathComponent:@"book.sqlite"] error:&outError];
    
    NSFNanoSearch *search = [NSFNanoSearch searchWithStore:nanoStore];
    search.filterClass = NSStringFromClass([Book class]);
    NSFNanoSortDescriptor *sortByKey = [[NSFNanoSortDescriptor alloc] initWithAttribute:@"title" ascending:NO];
    search.sort = [NSArray arrayWithObject:sortByKey];
    NSMutableArray *results = [search searchObjectsWithReturnType:NSFReturnObjects error:&outError];

    books = [[NSMutableArray alloc] init];
    for (Book *book in results){
        [books addObject:book];
    }
    [tableView reloadData];
}

- (IBAction)generate:(id)sender {
    NSString *docs = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSError *outError;
    NSFNanoStore *nanoStore = [NSFNanoStore createAndOpenStoreWithType:NSFPersistentStoreType path:[docs stringByAppendingPathComponent:@"book.sqlite"] error:&outError];
    [nanoStore openWithError:&outError];
    
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSString stringWithFormat:@"Title %d",books.count],kBookTitle,
                          [NSString stringWithFormat:@"Author %d",books.count],kBookAuthor, nil];
    Book *toSave = [[Book alloc] initNanoObjectFromDictionaryRepresentation:dict forKey:nil store:nanoStore];
    [nanoStore addObject:toSave error:&outError];
    [nanoStore saveStoreAndReturnError:&outError];
    [nanoStore closeWithError:&outError];
    
    [self reloadData];
    
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return books.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"BookCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    UILabel *title = (UILabel *)[cell viewWithTag:1];
    
    Book *book = [books objectAtIndex:indexPath.row];
    [title setText:book.title];
    
    return cell;
}

- (BOOL) tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete){
        Book *toRemove = [books objectAtIndex:indexPath.row];
        
        NSString *docs = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
        NSError *outError;
        NSFNanoStore *nanoStore = [NSFNanoStore createAndOpenStoreWithType:NSFPersistentStoreType path:[docs stringByAppendingPathComponent:@"book.sqlite"] error:&outError];
        [nanoStore openWithError:&outError];
        [nanoStore removeObject:toRemove error:&outError];
        [nanoStore saveStoreAndReturnError:&outError];
        [nanoStore closeWithError:&outError];
        
        [self reloadData];
    }
}

@end
