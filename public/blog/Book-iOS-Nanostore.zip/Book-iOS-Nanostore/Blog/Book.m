//
//  Book.m
//  Blog
//
//  Created by Daniele Bottillo on 5/26/13.
//  Copyright (c) 2013 Daniele Bottillo. All rights reserved.
//

#import "Book.h"

#import "Book.h"

@implementation Book

@synthesize title, author;

- (id)initNanoObjectFromDictionaryRepresentation:(NSDictionary *)theDictionary forKey:(NSString *)aKey store:(NSFNanoStore *)theStore{
    if (self = [super initNanoObjectFromDictionaryRepresentation:theDictionary forKey:aKey store:theStore]){
        if (theDictionary != nil){
            self.title = [theDictionary objectForKey: kBookTitle];
            self.author = [theDictionary objectForKey: kBookAuthor];
        }
    }
    return self;
}

- (NSDictionary *)nanoObjectDictionaryRepresentation{
    NSMutableDictionary *representation = [[NSMutableDictionary alloc] init];
    [representation setValue:title forKey:kBookTitle];
    [representation setValue:author forKey:kBookAuthor];
    
    return representation;
}

- (NSString *)debugDescription{
    return [NSString stringWithFormat:@"BOOK - %@",self.key];
}

- (id)rootObject{
    return self;
}

@end