//
//  Book.h
//  Blog
//
//  Created by Daniele Bottillo on 5/26/13.
//  Copyright (c) 2013 Daniele Bottillo. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "NSFNanoObject.h"

@interface Book : NSFNanoObject

#define     kBookTitle      @"title"
#define     kBookAuthor    @"author"

@property (strong, nonatomic) NSString *title;
@property (strong, nonatomic) NSString *author;

@end