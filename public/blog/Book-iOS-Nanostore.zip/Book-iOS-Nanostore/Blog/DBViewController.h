//
//  DBViewController.h
//  Blog
//
//  Created by Daniele Bottillo on 5/26/13.
//  Copyright (c) 2013 Daniele Bottillo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DBViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *tableView;
- (IBAction)generate:(id)sender;

@end
